<!DOCTYPE html>
<html>
<head>
  <title>User Detail</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="<?php echo base_url();?>css/jquery-ui.css"></script>
  <link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

  

</head>
<body>

  <div class="container">
   <br>

    <a class="btn btn-danger" href="<?php echo base_url('/index.php/Welcome/logout');?>">Log Out</a>
    <a class="btn btn-primary" href="<?php echo base_url('/index.php/Welcome/input');?>">Input</a>

    <center><h4><strong>Save Your Friends Contact now!</strong></h4></center>

   <?php //print_r($getAlluser);?>
     <table class="table table-bordered table-hover" id="myTable">
    <thead>
      <tr>
        <th scope="col">No.</th>
        <th scope="col">Name</th>
        <th scope="col">Contact Number</th>
        <th scope="col">Address</th>
      </tr>
    </thead>
    <tbody>
      <?php
       $sl = '1';
       foreach($getAlluser as $row):?>
      <tr>
        <th scope="row"><?php echo $sl;?></th>
        <td><?php echo $row['name'];?></td>
        <td><?php echo $row['phone_no'];?></td>
        <td><?php echo $row['address'];?></td>
      </tr>

    <?php $sl ++;
    endforeach;
     ?>

     </tbody>
  </table>
 </div>

<!-- Modal -->
<div class="modal fade" id="tambah_peneliti" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">FORM INPUT  FRIENDS CONTACT'S!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url(). 'admin/Welcome/input' ?>" method = "post" enctype = "multipart/form-data">
          <div class="form-group">
            <label>Name </label>
            <input type="text" name="name" class="form-control">
          </div>
          <div class="form-group">
            <label>Contact Number</label>
            <input type="text" name="phone_no" class="form-control">
          </div>
          <div class="form-group">
            <label>Address</label>
            <input type="text" name="address" class="form-control">
          </div>
      </form>
    </div>
  </div>
</div>

   <script type="text/javascript">
    $(document).ready( function () {

      $('#myTable').DataTable();
  });
 </script>

</body>
</html>